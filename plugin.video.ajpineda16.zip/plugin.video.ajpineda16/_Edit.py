import xbmcaddon

MainBase = 'http://ajpineda16addon.atwebpages.com/menu'
addon = xbmcaddon.Addon('plugin.video.ajpineda16')